<!DOCTYPE html>
<html>
<head>
  <title>Discounted Products Slideshow</title>
  <link rel="stylesheet" href="slide.css">

</head>
<body>
  <div class="untitled">
    <div class="untitled__slides">
      <?php
      include("connect.php");

      try {
        // Fetch all products with discounts
        $sql = "SELECT id_prod, nom_prod, prix, discounted_price, im_front, im_back, im_left, im_right 
                FROM produit WHERE discounted_price > 0";
        $stmt = $cnx->prepare($sql);
        $stmt->execute();
        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($products) {
          foreach ($products as $product) {
            $images = [
              $product['im_front'],
              $product['im_back'],
              $product['im_left'],
              $product['im_right']
            ];

            foreach ($images as $image) {
              if (!empty($image)) {
                $base64Image = base64_encode($image);
                ?>
                <div class="untitled__slide">
                  <div class="untitled__slideBg" style="background-image: url('data:image/jpeg;base64,<?php echo $base64Image; ?>');"></div>
                  <div class="untitled__slideContent">
                    <h3><?php echo htmlspecialchars($product['nom_prod']); ?></h3>
                    <p>Original Price: $<?php echo number_format($product['prix'], 2); ?></p>
                    <p>Discounted Price: $<?php echo number_format($product['discounted_price'], 2); ?></p>
                  </div>
                </div>
                <?php
              }
            }
          }
        } else {
          echo "<p>No discounted products found.</p>";
        }
      } catch (PDOException $e) {
        echo "<p>Error fetching products: " . $e->getMessage() . "</p>";
      }
      ?>
    </div>
  </div>

  <script>
const slides = document.querySelectorAll('.untitled__slide');
let currentSlideIndex = 0;
let currentProductIndex = 0;
const products = document.querySelectorAll('.untitled__slide'); // All product slides

function showSlide(index) {
  slides.forEach((slide, i) => {
    const bg = slide.querySelector('.untitled__slideBg');
    const content = slide.querySelector('.untitled__slideContent');
    
    // Check if it's the last image in the current product (4 images per product)
    if (i === index && i % 4 === 3) {
      slide.classList.add('split');  // Apply split effect on last image of the product
    } else {
      slide.classList.remove('split');  // Remove split effect
    }

    if (i === index) {
      slide.classList.add('active');  // Show the current slide
    } else {
      slide.classList.remove('active');  // Hide other slides
    }
  });
}

function nextSlide() {
  // Move to the next product at the last image
  if ((currentSlideIndex + 1) % 4 === 0) {
    currentProductIndex++;
  }

  currentSlideIndex = (currentSlideIndex + 1) % slides.length;
  showSlide(currentSlideIndex);
}

// Initialize slideshow
if (slides.length > 0) {
  showSlide(0);
  setInterval(nextSlide, 3000); // 3 seconds per slide
}

  </script>
</body>
</html>
