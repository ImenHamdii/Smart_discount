<head>
<title>
    Boutique
</title>
<link rel="stylesheet" href="ajout.css"  type="text/css" />
  </head>

<body>
<strong><h1><i> Creation de compte </i></h1></strong>

<form method="POST" action="">

<table  >
    <tr> <td> numero user: </td></tr><tr> <td><label><input name="numuser" type="number" required></label> </td></tr>
    <tr><td> Nom:</td> </tr><tr> <td><label> <input name="nom" type="text" required></label></td></tr>
    <tr><td> Prenom: </td> </tr><tr> <td><label><input name="prenom" type="text" required></label></td></tr>
    <tr> <td> mail :</td> </tr><tr><td><label><input name="mail" type="text"></label></td></tr>
    <tr> <td> mot de passe :</td></tr><tr><td><label> <input name="pwd" type="password" required></label></td></tr>
<tr><td colspan='2'>
<button name="log">Ajouter </button></td></tr>
</table>


<?php
if (!empty($_POST['numuser']) && !empty($_POST['nom']) && !empty($_POST['prenom']) && !empty($_POST['mail']) && !empty($_POST['pwd'])) {
    try {
        include("../connect.php");
        $mail = $_POST['mail'];
        $u = "SELECT * FROM user WHERE mail = ?"; // if there is a mail like this it will show 
        $stmt = $cnx->prepare($u);
        $stmt->execute([$mail]);
        $s = $stmt->fetch();

        if ($s) {
                echo "<br><h3 style='color:teal'>il y a user de cette mail donner un autre mail</h3>";
            } else {
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $numuser = $_POST['numuser']; 
    $pwd = $_POST['pwd'];
    

        $p = "INSERT INTO user VALUES ('$mail','$pwd','$nom','$prenom','$numuser')";
   $st = $cnx->query($p);
   echo "<br><h3 style='color:teal'>ajouter avec succes \"welcome to our team\"</h3>";
   echo "<br><br> <a href='login.php'>"?> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-door-open" viewBox="0 0 16 16">
   <path d="M8.5 10c-.276 0-.5-.448-.5-1s.224-1 .5-1 .5.448.5 1-.224 1-.5 1z"/>
   <path d="M10.828.122A.5.5 0 0 1 11 .5V1h.5A1.5 1.5 0 0 1 13 2.5V15h1.5a.5.5 0 0 1 0 1h-13a.5.5 0 0 1 0-1H3V1.5a.5.5 0 0 1 .43-.495l7-1a.5.5 0 0 1 .398.117zM11.5 2H11v13h1V2.5a.5.5 0 0 0-.5-.5zM4 1.934V15h6V1.077l-6 .857z"/>
    </svg>connecte </a><?php
   }

} catch (PDOException $e) {
echo "Connection failed: " . $e->getMessage();
}
}

?>

</form>
<footer> 
<a href="login.php"> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box-arrow-in-right" viewBox="0 0 16 16">
<path fill-rule="evenodd" d="M6 3.5a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-2a.5.5 0 0 0-1 0v2A1.5 1.5 0 0 0 6.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-8A1.5 1.5 0 0 0 5 3.5v2a.5.5 0 0 0 1 0v-2z"/>
<path fill-rule="evenodd" d="M11.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H1.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3z"/>
</svg>connexion </a>
</body>

