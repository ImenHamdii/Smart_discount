<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action'])) {
    // Ajout, modification ou suppression de produits
    // Récupérer les données, exécuter la requête SQL correspondante et rafraîchir la page
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Gestion des Produits</title>
</head>
<body>
    <h2>Liste des Produits</h2>
    <table border="1">
        <tr>
            <th>Nom</th>
            <th>Prix</th>
            <th>Prix Soldé</th>
            <th>Stock</th>
            <th>Actions</th>
        </tr>
        <?php
        $sql = "SELECT * FROM produits";
        $result = $conn->query($sql);
        while ($produit = $result->fetch_assoc()) {
            echo "<tr>
                <td>{$produit['nom']}</td>
                <td>{$produit['prix']}</td>
                <td>{$produit['prix_solde']}</td>
                <td>{$produit['stock']}</td>
                <td>
                    <button>Modifier</button>
                    <button>Supprimer</button>
                </td>
            </tr>";
        }
        ?>
    </table>
    <h3>Ajouter un Produit</h3>
    <form method="post" action="">
        <input type="text" name="nom" placeholder="Nom du produit" required>
        <input type="number" name="prix" placeholder="Prix" required>
        <input type="number" name="prix_solde" placeholder="Prix Soldé">
        <input type="number" name="stock" placeholder="Stock">
        <button type="submit" name="action" value="ajouter">Ajouter</button>
    </form>
</body>
</html>
