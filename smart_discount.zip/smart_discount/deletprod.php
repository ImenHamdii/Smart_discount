<!DOCTYPE html>
<html>
<head>
  <title>Delete Product</title>
  <link rel="stylesheet" href="smart.css">
</head>
<body>
  <h2>Delete Product</h2>

  <?php
  include("connect.php");

  // Check if ID is passed via GET
  $id = isset($_GET['id']) ? intval($_GET['id']) : null;

  if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($id)) {
    // Delete the product
    $sql = "DELETE FROM produit WHERE id_prod = ?";
    $stmt = $cnx->prepare($sql);

    try {
      $stmt->execute([$id]);
      echo "<p>Product with ID $id has been deleted successfully!</p>";
    } catch (PDOException $e) {
      echo "<p>Error deleting product: " . $e->getMessage() . "</p>";
    }
  } elseif ($id) {
    // Retrieve product details including the front image (BLOB)
    $sql = "SELECT nom_prod, prix, im_front FROM produit WHERE id_prod = ?";
    $stmt = $cnx->prepare($sql);
    $stmt->execute([$id]);

    if ($product = $stmt->fetch(PDO::FETCH_ASSOC)) {
      // Convert BLOB image data to base64
      $imageData = $product['im_front'];
      $base64Image = !empty($imageData) ? 'data:image/jpeg;base64,' . base64_encode($imageData) : null;

      echo "<h3>Are you sure you want to delete this product?</h3>";
      echo "<p>Product Name: " . htmlspecialchars($product['nom_prod']) . "</p>";
      echo "<p>Price: $" . number_format($product['prix'], 2) . "</p>";

      // Display the front image if available
      if ($base64Image) {
        echo '<p><img src="' . $base64Image . '" alt="Product Image" style="max-width:300px; height: 400px;;"></p>';
      } else {
        echo '<p><em>No image available for this product.</em></p>';
      }

      // Confirmation form
      ?>
      <form method="POST" action="?id=<?php echo urlencode($id); ?>">
        <button type="submit">Yes, Delete</button>
        <a href="main.php">Cancel</a>
      </form>
      <?php
    } else {
      echo "<p>No product found with ID: " . htmlspecialchars($id) . "</p>";
    }
  } else {
    echo "<p>Product ID is required to delete a product.</p>";
  }
  ?>

  <footer>
    <br><br>
    <a href="main.php">
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
        <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
        <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
      </svg>
      main page
    </a>
  </footer>
</body>
</html>
