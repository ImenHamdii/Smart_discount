<?php
include("connect.php");

error_log("Received parameters: " . print_r($_GET, true)); // Log received parameters

if (isset($_GET['id']) && isset($_GET['column'])) {
    $id = $_GET['id'];
    $column = $_GET['column'];

    // Prepare and execute the SQL statement to fetch the image
    $sql = "SELECT $column FROM produit WHERE id_prod = :id";
    $stmt = $cnx->prepare($sql);
    $stmt->bindParam(':id', $id);
    
    try {
        $stmt->execute();

        if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            if (isset($row[$column]) && !empty($row[$column])) {
                header("Content-Type: image/png"); // Change this if your images are of a different type
                echo $row[$column]; // Output the BLOB data
                exit;
            } else {
                header("HTTP/1.0 404 Not Found");
                echo "Image not found.";
                exit;
            }
        } else {
            header("HTTP/1.0 404 Not Found");
            echo "No product found with the given ID.";
            exit;
        }
    } catch (PDOException $e) {
        header("HTTP/1.0 500 Internal Server Error");
        echo "Database error: " . htmlspecialchars($e->getMessage());
        exit;
    }
} else {
    header("HTTP/1.0 400 Bad Request");
    echo "Invalid request.";
    exit;
}
?>