<!DOCTYPE html>
<html>
<?php session_start(); ?>
<head>
    <title>Product Slideshow</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1><?php echo "Hello " . htmlspecialchars($_SESSION['nom'] ?? 'Guest'); ?></h1>
    <br>
    <table>
        <thead>
            <tr>
                <th>Images</th>
                <th>Product ID</th>
                <th>Product Name</th>
                <th>Price</th>
                <th>Discount</th>
                <th>Update Discount</th>
            </tr>
        </thead>
        <tbody>
            <?php
            include("connect.php");

            $sql = "SELECT * FROM produit"; // Select all products
            $stmt = $cnx->prepare($sql);
            $stmt->execute();

            if ($stmt->rowCount() > 0) {
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo "<tr>";
                    echo "<td>";
                    ?>
                    <div class="product-slideshow">
                        <?php
                        $imageColumns = ['im_front', 'im_back', 'im_left', 'im_right'];
                        $hasImage = false;

                        foreach ($imageColumns as $column) {
                            if (!empty($row[$column])) {
                                // Convert BLOB data to a Base64 string
                                $base64Image = base64_encode($row[$column]);
                                echo "<img src='data:image/jpeg;base64,{$base64Image}' alt='Product Image'>";
                                $hasImage = true;
                            }
                        }

                        if (!$hasImage) {
                            echo "<img src='placeholder.png' alt='Placeholder Image'>"; // Show placeholder image
                        }
                        ?>
                    </div>
                    <?php
                    echo "</td>";
                    echo "<td>" . htmlspecialchars($row['id_prod'] ?? '') . "</td>";
                    echo "<td>" . htmlspecialchars($row['nom_prod'] ?? '') . "</td>";
                    echo "<td>$" . htmlspecialchars($row['prix'] ?? '0.00') . "</td>";
                    echo "<td>$" . htmlspecialchars($row['discounted_price'] ?? '0.00') . "</td>";
                    echo "<td>";
                    ?>
<svg width="20px" height="20px" viewBox="0 0 24 24" id="discount" xmlns="http://www.w3.org/2000/svg" class="icon multi-color" fill="#000000"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"><title style="stroke-width: 2;">discount</title><path id="tertiary-fill" d="M20,10c-.68-.61-1.63-.89-2.31-1.48-.84-.76-1.43-2.23-2.44-2.64s-2.16.37-3.24.37-2.27-.76-3.25-.37S7.16,7.75,6.32,8.51C5.63,9.1,4.68,9.38,4,10a9.68,9.68,0,0,0,.12-1.13,4.23,4.23,0,0,1,.31-1.63A2.94,2.94,0,0,1,5.6,6.38,6.53,6.53,0,0,0,7,5.49,8.26,8.26,0,0,0,8.08,4.17,3.3,3.3,0,0,1,9.11,3a.75.75,0,0,1,.28,0,4.32,4.32,0,0,1,1,.21A6.35,6.35,0,0,0,12,3.48a6.27,6.27,0,0,0,1.56-.27A2.75,2.75,0,0,1,14.91,3a3.51,3.51,0,0,1,1,1.13A7.65,7.65,0,0,0,17,5.49a7.14,7.14,0,0,0,1.38.89,3.14,3.14,0,0,1,1.18.86,4.68,4.68,0,0,1,.3,1.63C19.91,9.21,19.94,9.6,20,10Z" style="fill: #b7b7b7; stroke-width: 2;"></path><path id="secondary-fill" d="M11,9.5A1.5,1.5,0,1,1,9.5,8,1.5,1.5,0,0,1,11,9.5ZM14.5,13A1.5,1.5,0,1,0,16,14.5,1.5,1.5,0,0,0,14.5,13Z" style="fill: #2ca9bc; stroke-width: 2;"></path><path id="primary-stroke" d="M9,15l6-6m5.22.33c-.3-.91-.1-2.08-.65-2.83S17.84,5.56,17.08,5,15.8,3.39,14.89,3.1,13,3.36,12,3.36s-2-.55-2.89-.26S7.68,4.46,6.92,5,5,5.73,4.43,6.5s-.35,1.92-.65,2.83S2.64,11,2.64,12s.86,1.79,1.14,2.67.1,2.08.65,2.83,1.73.94,2.49,1.49S8.2,20.61,9.11,20.9,11,20.64,12,20.64s2,.55,2.89.26,1.43-1.36,2.19-1.91,1.94-.72,2.49-1.49.35-1.92.65-2.83S21.36,13,21.36,12,20.5,10.21,20.22,9.33Z" style="fill: none; stroke: #000000; stroke-linecap: round; stroke-linejoin: round; stroke-width: 2;"></path></g></svg>
                    <?php
                    echo '<a href="update.php?id=' . urlencode($row['id_prod'] ?? '') . '">Update Discount</a>';
                    echo ' | ';
                    ?>
<svg width="20px" height="20px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M13 4H8.8C7.11984 4 6.27976 4 5.63803 4.32698C5.07354 4.6146 4.6146 5.07354 4.32698 5.63803C4 6.27976 4 7.11984 4 8.8V15.2C4 16.8802 4 17.7202 4.32698 18.362C4.6146 18.9265 5.07354 19.3854 5.63803 19.673C6.27976 20 7.11984 20 8.8 20H15.2C16.8802 20 17.7202 20 18.362 19.673C18.9265 19.3854 19.3854 18.9265 19.673 18.362C20 17.7202 20 16.8802 20 15.2V11" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path> <path d="M4 16L8.29289 11.7071C8.68342 11.3166 9.31658 11.3166 9.70711 11.7071L13 15M13 15L15.7929 12.2071C16.1834 11.8166 16.8166 11.8166 17.2071 12.2071L20 15M13 15L15.25 17.25" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path> <path d="M17 3L19 5M21 7L19 5M19 5L21 3M19 5L17 7" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path> </g></svg>

                    <?php
                    echo '<a href="deletprod.php?id=' . urlencode($row['id_prod'] ?? '') . '">Delete Product</a>';
                    echo "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='6'>No products found.</td></tr>";
            }
            ?>
        </tbody>
    </table>

    <script>
    const productSlideshows = document.querySelectorAll('.product-slideshow');

    productSlideshows.forEach(slideshow => {
        const images = slideshow.querySelectorAll('img');

        // Check if there are any images
        if (images.length === 0) {
            return; // Exit if no images are found
        }

        // Initially hide all images except the first one
        images.forEach((image, index) => {
            if (index !== 0) {
                image.style.display = 'none';
            }
        });

        let currentIndex = 0;

        function showNextImage() {
            images[currentIndex].style.display = 'none';
            currentIndex = (currentIndex + 1) % images.length;
            images[currentIndex].style.display = 'block';
        }

        // Set interval for 2 seconds per image
        setInterval(showNextImage, 2000);
    });
    </script>
            <footer> 

<br><br>
<a href="affich.php"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
<path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
<path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
</svg>Client</a>

<a href="prod/ajoutprod.php"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-book" viewBox="0 0 16 16">
<path d="M1 2.828c.885-.37 2.154-.769 3.388-.893 1.33-.134 2.458.063 3.112.752v9.746c-.935-.53-2.12-.603-3.213-.493-1.18.12-2.37.461-3.287.811V2.828zm7.5-.141c.654-.689 1.782-.886 3.112-.752 1.234.124 2.503.523 3.388.893v9.923c-.918-.35-2.107-.692-3.287-.81-1.094-.111-2.278-.039-3.213.492V2.687zM8 1.783C7.015.936 5.587.81 4.287.94c-1.514.153-3.042.672-3.994 1.105A.5.5 0 0 0 0 2.5v11a.5.5 0 0 0 .707.455c.882-.4 2.303-.881 3.68-1.02 1.409-.142 2.59.087 3.223.877a.5.5 0 0 0 .78 0c.633-.79 1.814-1.019 3.222-.877 1.378.139 2.8.62 3.681 1.02A.5.5 0 0 0 16 13.5v-11a.5.5 0 0 0-.293-.455c-.952-.433-2.48-.952-3.994-1.105C10.413.809 8.985.936 8 1.783z"/>
</svg>ajout produit</a>

<a href="ajoutuser/login.php"> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box-arrow-in-right" viewBox="0 0 16 16">
<path fill-rule="evenodd" d="M6 3.5a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-2a.5.5 0 0 0-1 0v2A1.5 1.5 0 0 0 6.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-8A1.5 1.5 0 0 0 5 3.5v2a.5.5 0 0 0 1 0v-2z"/>
<path fill-rule="evenodd" d="M11.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H1.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3z"/>
</svg>deconnexion </a>

</footer>
</body>
</html>
