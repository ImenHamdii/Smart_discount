<!DOCTYPE html>
<html>
<head>
  <title>Product Details</title>
  <link rel="stylesheet" href="../smart.css">
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 0;
      background: linear-gradient(135deg, #e3f2fd, #ffffff);
      text-align: center;
    }

    form {
      margin: 20px auto;
      padding: 10px;
    }

    .product-container {
      margin: 20px auto;
      text-align: center;
      padding: 20px;
      background: #fff;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
      border-radius: 10px;
      width: 80%;
      max-width: 600px;
    }

    .product-details {
      text-align: left;
      margin: 10px auto;
    }

    .product-details h2 {
      color: #007bff;
    }

    .product-details p {
      margin: 5px 0;
      color: #555;
    }

    .image-container {
      margin: 20px auto;
    }

    .image-container img {
      width: 400px;
      height: auto;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    .image-container p {
      color: #ff0000;
      font-weight: bold;
    }
  </style>
</head>
<body>
  <form method="POST" action="">
    <input name="id" type="number" required placeholder="Enter Product ID">
    <button type="submit">Rechercher</button>
  </form>

  <div class="product-container">
    <?php
    if (isset($_POST['id']) && !empty($_POST['id'])) {
        include("../connect.php");

        $id = intval($_POST['id']);
        $sql = "SELECT `id_prod`, `im_front`, `im_back`, `im_left`, `im_right`, `nom_prod`, `prix`, `discounted_price` FROM `produit` WHERE id_prod = ?";
        $stmt = $cnx->prepare($sql);
        $stmt->execute([$id]);

        $images = [];
        if ($stmt->rowCount() > 0) {
            $product = $stmt->fetch(PDO::FETCH_ASSOC);

            // Affichage des détails du produit
            echo "<div class='product-details'>";
            echo "<h2>" . htmlspecialchars($product['nom_prod']) . "</h2>";
            echo "<p><strong>Prix:</strong> " . number_format($product['prix'], 2) . " €</p>";
            echo "<p><strong>Prix remisé:</strong> " . number_format($product['discounted_price'], 2) . " €</p>";
            echo "</div>";

            // Gestion des images en BLOB
            $imageColumns = ['im_front', 'im_back', 'im_left', 'im_right'];
            foreach ($imageColumns as $column) {
                $blobData = $product[$column];
                if (!empty($blobData)) {
                    $base64Image = 'data:image/jpeg;base64,' . base64_encode($blobData);
                    $images[] = $base64Image;
                }
            }

            if (!empty($images)) {
                // Afficher la première image du diaporama
                echo "<div class='image-container'>";
                echo "<img id='slideshow-image' src='{$images[0]}' alt='Product Image'>";
                echo "</div>";
            } else {
                echo "<p>Aucune image trouvée pour ce produit.</p>";
            }
        } else {
            echo "<p>Produit introuvable avec l'ID : " . htmlspecialchars($id) . "</p>";
        }
    }
    ?>
  </div>

  <script>
    // JavaScript Slideshow
    const images = <?php echo json_encode($images ?? []); ?>; // Charger le tableau des images
    if (images.length > 0) {
        let currentIndex = 0;
        const slideshowImage = document.getElementById("slideshow-image");

        function showNextImage() {
            currentIndex = (currentIndex + 1) % images.length; // Cycle à travers les images
            slideshowImage.src = images[currentIndex];
        }

        // Alterner les images toutes les 2 secondes
        setInterval(showNextImage, 2000);
    } else {
        console.warn("Aucune image disponible pour le diaporama.");
    }
  </script>
</body>
</html>
