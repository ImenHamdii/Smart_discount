<?php
session_start();
?>
<head>
  <link href="../ajoutuser/ajout.css" rel="stylesheet"/>
</head>

<body>
  <strong><h1><i> Ajouter un produit </i></h1></strong>
  <br><br><br>
  <form method="POST" action="" enctype="multipart/form-data">
    <table>
      <tr>
        <td> id_produit </td>
        <td><input name="id" type="number" required></td>
      </tr>
      <tr>
        <td> nom produit </td>
        <td><input name="nom_prod" type="text" required></td>
      </tr>
      <tr>
        <td> prix </td>
        <td><input name="prix" type="float" required></td>
      </tr>
      <tr>
        <td> image front : </td>
        <td> <input name="img_front" type="file" accept="image/jpeg,image/png" required></td>
      </tr>
      <tr>
        <td> image back : </td>
        <td> <input name="img_back" type="file" accept="image/jpeg,image/png" required></td>
      </tr>
      <tr>
        <td> image left : </td>
        <td> <input name="img_left" type="file" accept="image/jpeg,image/png" required></td>
      </tr>
      <tr>
        <td> image right : </td>
        <td> <input name="img_right" type="file" accept="image/jpeg,image/png" required></td>
      </tr>
      <tr>
        <td colspan='2'><button type="submit" value="envoyer">Ajouter</button></td>
      </tr>
    </table>
  </form>

  <?php
  if (!empty($_POST['id'])) {
    include("../connect.php");

    $id = $_POST['id'];
    $u = "SELECT * FROM produit WHERE id_prod = ?"; // Check if the product ID already exists
    $stmt = $cnx->prepare($u);
    $stmt->execute([$id]);
    $s = $stmt->fetch();

    if ($s) {
      echo "<br><h3 style='color:teal'>Il y a un article avec cet ID, veuillez fournir un autre ID.</h3>";
    } else {
      try {
        if (isset($_POST['id']) && !empty($_POST['id'])) {
          $id = $_POST['id'];
          $prix = $_POST['prix'];
          $nom_prod = $_POST['nom_prod'];

          // Read the image data as binary for all 4 images
          $imgFront = file_get_contents($_FILES['img_front']['tmp_name']);
          $imgBack = file_get_contents($_FILES['img_back']['tmp_name']);
          $imgLeft = file_get_contents($_FILES['img_left']['tmp_name']);
          $imgRight = file_get_contents($_FILES['img_right']['tmp_name']);

          // Insert into the database
          $sql = "INSERT INTO produit (id_prod, im_front, im_back, im_left, im_right, nom_prod, prix)
                  VALUES (:id, :im_front, :im_back, :im_left, :im_right, :nom_prod, :prix)";
          $stmt = $cnx->prepare($sql);
          $stmt->bindParam(':id', $id, PDO::PARAM_INT);
          $stmt->bindParam(':im_front', $imgFront, PDO::PARAM_LOB);
          $stmt->bindParam(':im_back', $imgBack, PDO::PARAM_LOB);
          $stmt->bindParam(':im_left', $imgLeft, PDO::PARAM_LOB);
          $stmt->bindParam(':im_right', $imgRight, PDO::PARAM_LOB);
          $stmt->bindParam(':nom_prod', $nom_prod, PDO::PARAM_STR);
          $stmt->bindParam(':prix', $prix, PDO::PARAM_STR);

          if ($stmt->execute()) {
            echo "<br><p style='color:teal'>Le produit <b>$id</b> a été ajouté avec succès.</p>";
          } else {
            echo "<br><p style='color:red'>Une erreur s'est produite lors de l'ajout du produit.</p>";
          }
        } else {
          echo "<br><p style='color:red'>Veuillez saisir un ID de produit.</p>";
        }
      } catch (PDOException $e) {
        echo "<br><p style='color:red'>Une erreur s'est produite : " . $e->getMessage() . "</p>";
      }
    }
  } else {
    echo "<br><p style='color:red'>Veuillez remplir tous les champs.</p>";
  }
  ?>
        <footer> 

<br><br>
<a href="affiche.php"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
<path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
<path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
</svg>affiche produit</a>

<a href="../main.php"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-book" viewBox="0 0 16 16">
<path d="M1 2.828c.885-.37 2.154-.769 3.388-.893 1.33-.134 2.458.063 3.112.752v9.746c-.935-.53-2.12-.603-3.213-.493-1.18.12-2.37.461-3.287.811V2.828zm7.5-.141c.654-.689 1.782-.886 3.112-.752 1.234.124 2.503.523 3.388.893v9.923c-.918-.35-2.107-.692-3.287-.81-1.094-.111-2.278-.039-3.213.492V2.687zM8 1.783C7.015.936 5.587.81 4.287.94c-1.514.153-3.042.672-3.994 1.105A.5.5 0 0 0 0 2.5v11a.5.5 0 0 0 .707.455c.882-.4 2.303-.881 3.68-1.02 1.409-.142 2.59.087 3.223.877a.5.5 0 0 0 .78 0c.633-.79 1.814-1.019 3.222-.877 1.378.139 2.8.62 3.681 1.02A.5.5 0 0 0 16 13.5v-11a.5.5 0 0 0-.293-.455c-.952-.433-2.48-.952-3.994-1.105C10.413.809 8.985.936 8 1.783z"/>
</svg>page d'accueil</a>

<a href="../ajoutuser/login.php"> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box-arrow-in-right" viewBox="0 0 16 16">
<path fill-rule="evenodd" d="M6 3.5a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-2a.5.5 0 0 0-1 0v2A1.5 1.5 0 0 0 6.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-8A1.5 1.5 0 0 0 5 3.5v2a.5.5 0 0 0 1 0v-2z"/>
<path fill-rule="evenodd" d="M11.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H1.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3z"/>
</svg>deconnexion </a>

</footer>
</body>
</html>
