<!DOCTYPE html>
<html>
<head>
  <title>Apply Discount to Product</title>
  <link rel="stylesheet" href="smart.css">
</head>
<body>
  <h2>Apply Discount to Product</h2>

  <!-- Form to enter Product ID and Discount Percentage -->
  <form method="POST" action="">
    <label for="id">Product ID:</label>
    <input type="number" name="id" id="id" required placeholder="Enter Product ID">
    
    <label for="discount">Discount Percentage:</label>
    <input type="number" name="discount" id="discount" min="0" max="100" required placeholder="Enter Discount %">
    
    <button type="submit" value="apply">Apply Discount</button>
  </form>

  <?php
  if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'], $_POST['discount'])) {
      include("../connect.php");

      $id = intval($_POST['id']);
      $discount = floatval($_POST['discount']);

      // Fetch product details from the database
      $sql = "SELECT prix, im_front FROM produit WHERE id_prod = ?";
      $stmt = $cnx->prepare($sql);
      $stmt->execute([$id]);

      if ($product = $stmt->fetch(PDO::FETCH_ASSOC)) {
          $originalPrice = $product['prix'];
          $discountAmount = ($originalPrice * $discount) / 100;
          $discountedPrice = $originalPrice - $discountAmount;

          // Update discounted price in the database
          $updateSql = "UPDATE produit SET discounted_price = ? WHERE id_prod = ?";
          $updateStmt = $cnx->prepare($updateSql);
          $updateStmt->execute([$discountedPrice, $id]);

          // Display the product with discount details
          echo "<div class='discounted-product'>";
          echo "<p>Original Price: $" . number_format($originalPrice, 2) . "</p>";
          echo "<p>Discounted Price: $" . number_format($discountedPrice, 2) . " (" . $discount . "% off)</p>";

          // Display the front image of the product
          $imagePath = $product['im_front'];
          if (!empty($imagePath) && file_exists($imagePath)) {
              echo "<img src='$imagePath' alt='Discounted Product Image'>";
          } else {
              echo "<p>No image available for this product.</p>";
          }

          echo "</div>";
      } else {
          echo "<p>No product found with ID: " . htmlspecialchars($id) . "</p>";
      }
  }
  ?>
</body>
</html>
