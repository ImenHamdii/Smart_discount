const express = require('express');
const http = require('http').createServer(app);
const io = require('socket.io')(http);
const mysql = require('mysql2/promise');
const socket = io('http://localhost:8081'); // Replace with your server port

const app = express();

app.use(express.static('public'));

io.on('connection', (socket) => {
  console.log('A TV connected');

  async function getProductData() {
    const connection = await mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: '',
        database: 'smart_discount'
    });

    try {
      const [rows] = await connection.execute('SELECT * FROM produit');
      return rows;
    } catch (error) {
      console.error('Error fetching product data:', error);
      return [];
    } finally {
      connection.end();
    }
  }

  async function generateSlideshowHTML(productData) {
    let htmlString = `<div class="product-container">`;

    for (const product of productData) {
      htmlString += `<div class="product">`;
      const imageColumns = ['im_front', 'im_back', 'im_left', 'im_right'];

      for (const column of imageColumns) {
        const imagePath = product[column];
        if (!empty(imagePath) && file_exists(imagePath)) {
          htmlString += `<img src="${imagePath}" alt="Product Image">`;
        }
      }
      htmlString += `</div>`;
    }

    htmlString += `</div>`;

    htmlString += `<script>
      const productContainers = document.querySelectorAll('.product');

      productContainers.forEach(container => {
        const images = container.querySelectorAll('img');

        // Initially hide all images except the first one
        images.forEach((image, index) => {
          if (index !== 0) {
            image.style.display = 'none';
          }
        });

        let currentIndex = 0;

        function showNextImage() {
          images[currentIndex].style.display = 'none';
          currentIndex = (currentIndex + 1) % images.length;
          images[currentIndex].style.display = 'block';
        }

        // Set interval for 20 seconds per image
        setInterval(showNextImage, 2000);
      });
    </script>`;

    return htmlString;
  }

  getProductData()
    .then(products => {
      const htmlContent = generateSlideshowHTML(products);
      socket.emit('updateContent', { html: htmlContent });
    })
    .catch(error => {
      console.error('Error generating HTML:', error);
    });
});

http.listen(8081, () => {
  console.log('Server listening on port 3000');
});