<!DOCTYPE html>
<html>
<head>
  <title>Apply Discount to Product</title>
  <link rel="stylesheet" href="smart.css">
</head>
<body>
  <h2>Apply Discount to Product</h2>

  <?php
  include("connect.php");

  $id = isset($_GET['id']) ? intval($_GET['id']) : null;

  if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($id, $_POST['discount'])) {
    $discount = filter_var($_POST['discount'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 0, 'max_range' => 100]]);

    if ($discount !== false) {
      // Fetch product details
      $sql = "SELECT prix FROM produit WHERE id_prod = ?";
      $stmt = $cnx->prepare($sql);
      $stmt->execute([$id]);

      if ($product = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $originalPrice = $product['prix'];
        $discountAmount = ($originalPrice * $discount) / 100;
        $discountedPrice = $originalPrice - $discountAmount;

        // Update discounted price in the database
        $updateSql = "UPDATE produit SET discounted_price = ? WHERE id_prod = ?";
        $updateStmt = $cnx->prepare($updateSql);

        try {
          $updateStmt->execute([$discountedPrice, $id]);
          echo "<p>Discount applied successfully!</p>";
          echo "<p>Original Price: $" . number_format($originalPrice, 2) . "</p>";
          echo "<p>Discounted Price: $" . number_format($discountedPrice, 2) . " (" . $discount . "% off)</p>";

          // Fetch all images for the slideshow
          $sql = "SELECT nom_prod, im_front, im_back, im_left, im_right FROM produit WHERE id_prod = ?";
          $stmt = $cnx->prepare($sql);
          $stmt->execute([$id]);

          if ($product = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $images = [
              $product['im_front'],
              $product['im_back'],
              $product['im_left'],
              $product['im_right'],
            ];
            ?>
            <div class="product-slideshow">
              <?php
              foreach ($images as $image) {
                if (!empty($image)) {
                  $base64Image = base64_encode($image);
                  echo "<img src='data:image/jpeg;base64,{$base64Image}' alt='Product Image'>";
                }
              }
              ?>
            </div>
            <?php
          }
        } catch (PDOException $e) {
          echo "<p>Error updating product: " . $e->getMessage() . "</p>";
        }
      } else {
        echo "<p>No product found with ID: " . htmlspecialchars($id) . "</p>";
      }
    } else {
      echo "<p>Invalid discount percentage. Please enter a value between 0 and 100.</p>";
    }
  } elseif ($id) {
    // Fetch initial product details
    $sql = "SELECT nom_prod, prix, im_front FROM produit WHERE id_prod = ?";
    $stmt = $cnx->prepare($sql);
    $stmt->execute([$id]);

    if ($product = $stmt->fetch(PDO::FETCH_ASSOC)) {
      echo "<h3>Product: " . htmlspecialchars($product['nom_prod']) . "</h3>";
      echo "<p>Original Price: $" . number_format($product['prix'], 2) . "</p>";

      // Display the initial front image
      if (!empty($product['im_front'])) {
        $base64Image = base64_encode($product['im_front']);
        echo "<div class='product-slideshow'>";
        echo "<img src='data:image/jpeg;base64,{$base64Image}' alt='Product Image'>";
        echo "</div>";
      }

      // Discount input form
      ?>
      <form method="POST" action="?id=<?php echo urlencode($id); ?>">
        <label for="discount">Discount Percentage:</label>
        <input type="number" name="discount" id="discount" min="0" max="100" required placeholder="Enter Discount %">
        <button type="submit" value="apply">Apply Discount</button>
      </form>
      <?php
    } else {
      echo "<p>No product found with ID: " . htmlspecialchars($id) . "</p>";
    }
  } else {
    echo "<p>Product ID is required to apply a discount.</p>";
  }
  ?>

  <script>
    // JavaScript for image slideshow
    const productSlideshows = document.querySelectorAll('.product-slideshow');

    productSlideshows.forEach(slideshow => {
      const images = slideshow.querySelectorAll('img');

      if (images.length <= 1) return; // Exit if there's only one image

      // Initially hide all images except the first one
      images.forEach((image, index) => {
        if (index !== 0) {
          image.style.display = 'none';
        }
      });

      let currentIndex = 0;

      function showNextImage() {
        images[currentIndex].style.display = 'none';
        currentIndex = (currentIndex + 1) % images.length;
        images[currentIndex].style.display = 'block';
      }

      // Set interval for 2 seconds per image
      setInterval(showNextImage, 2000);
    });
  </script>
              <footer> 

<br><br>
<a href="main.php"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
<path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
<path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
</svg>main page</a>

<a href="prod/ajoutprod.php"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-book" viewBox="0 0 16 16">
<path d="M1 2.828c.885-.37 2.154-.769 3.388-.893 1.33-.134 2.458.063 3.112.752v9.746c-.935-.53-2.12-.603-3.213-.493-1.18.12-2.37.461-3.287.811V2.828zm7.5-.141c.654-.689 1.782-.886 3.112-.752 1.234.124 2.503.523 3.388.893v9.923c-.918-.35-2.107-.692-3.287-.81-1.094-.111-2.278-.039-3.213.492V2.687zM8 1.783C7.015.936 5.587.81 4.287.94c-1.514.153-3.042.672-3.994 1.105A.5.5 0 0 0 0 2.5v11a.5.5 0 0 0 .707.455c.882-.4 2.303-.881 3.68-1.02 1.409-.142 2.59.087 3.223.877a.5.5 0 0 0 .78 0c.633-.79 1.814-1.019 3.222-.877 1.378.139 2.8.62 3.681 1.02A.5.5 0 0 0 16 13.5v-11a.5.5 0 0 0-.293-.455c-.952-.433-2.48-.952-3.994-1.105C10.413.809 8.985.936 8 1.783z"/>
</svg>ajout produit</a>

<a href="ajoutuser/login.php"> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box-arrow-in-right" viewBox="0 0 16 16">
<path fill-rule="evenodd" d="M6 3.5a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-2a.5.5 0 0 0-1 0v2A1.5 1.5 0 0 0 6.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-8A1.5 1.5 0 0 0 5 3.5v2a.5.5 0 0 0 1 0v-2z"/>
<path fill-rule="evenodd" d="M11.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H1.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3z"/>
</svg>deconnexion </a>

</footer>
</body>
</html>
